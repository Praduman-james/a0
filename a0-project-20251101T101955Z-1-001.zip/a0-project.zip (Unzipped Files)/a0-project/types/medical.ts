export type MedicalConsultation = {
  id: string;
  timestamp: number;
  symptoms: string;
  age: string;
  diagnosis: string;
};

export type EmergencyContact = {
  name: string;
  number: string;
  icon: string;
  color: string;
};

export type MedicationCategory = {
  id: string;
  name: string;
  description: string;
  commonMedications: string[];
  warnings: string[];
};
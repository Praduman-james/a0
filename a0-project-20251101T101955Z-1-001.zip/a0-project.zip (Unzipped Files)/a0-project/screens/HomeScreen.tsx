import React, { useState, useRef } from 'react';
import Animated, { 
  FadeInUp, 
  FadeInDown, 
  withSpring, 
  useAnimatedStyle, 
  useSharedValue,
  withSequence,
  withTiming 
} from 'react-native-reanimated';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { toast } from 'sonner-native';

export default function AIDoctor() {
  const [symptoms, setSymptoms] = useState('');
  const [age, setAge] = useState('');
  const [loading, setLoading] = useState(false);
  const [diagnosis, setDiagnosis] = useState(null);

  const getMedicalAdvice = async () => {
    if (!symptoms || !age) {
      toast.error('Please enter both symptoms and age');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('https://api.a0.dev/ai/llm', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [
            {
              role: 'system',
              content: `You are an AI medical assistant. Provide helpful medical information and suggestions. 
                       Always start with a disclaimer. Consider the patient's age: ${age}. 
                       Format response in sections: 
                       1. Possible Conditions
                       2. Recommended Medications (including dosage based on age)
                       3. General Advice
                       4. When to See a Doctor
                       5. Home Care Tips
                       
                       Important guidelines for medication recommendations:
                       - Consider age-appropriate dosages
                       - Mention common over-the-counter options when applicable
                       - Include warnings about potential side effects
                       - Always advise consulting a pharmacist before taking any medication
                       
                       Keep responses clear and concise.`
            },
            {
              role: 'user',
              content: `Patient Age: ${age}. Symptoms: ${symptoms}`
            }
          ]
        }),
      });

      const data = await response.json();
      setDiagnosis(data.completion);
    } catch (error) {
      toast.error('Unable to get medical advice. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const scale = useSharedValue(1);
  const buttonStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: scale.value }]
    };
  });

  const handlePressIn = () => {
    scale.value = withSpring(0.95);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <Animated.View entering={FadeInDown.duration(600)}>
          <View style={styles.header}>
            <MaterialIcons name="medical-services" size={40} color="#2196F3" />
            <Text style={styles.title}>AI Doctor Assistant</Text>
          </View>

          <View style={styles.disclaimer}>
            <MaterialIcons name="warning" size={24} color="#FF9800" />
            <Text style={styles.disclaimerText}>
              This is an AI assistant for educational purposes only. Always consult a real medical professional for health concerns.
            </Text>
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Age</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter age"
              value={age}
              onChangeText={setAge}
              keyboardType="numeric"
            />

            <Text style={styles.label}>Symptoms</Text>
            <TextInput
              style={[styles.input, styles.symptomsInput]}
              placeholder="Describe your symptoms in detail..."
              value={symptoms}
              onChangeText={setSymptoms}
              multiline
              numberOfLines={4}
            />

            <Animated.View style={buttonStyle}>
              <TouchableOpacity
                style={styles.button}
                onPress={getMedicalAdvice}
                onPressIn={handlePressIn}
                onPressOut={handlePressOut}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="white" />
                ) : (
                  <Text style={styles.buttonText}>Get Medical Advice</Text>
                )}
              </TouchableOpacity>
            </Animated.View>
          </View>

          {diagnosis && (
            <View style={styles.diagnosisContainer}>
              <Text style={styles.diagnosisText}>{diagnosis}</Text>
            </View>
          )}

          <View style={styles.emergencySection}>
            <Text style={styles.emergencyTitle}>Emergency Services</Text>
            <View style={styles.emergencyButtonsContainer}>
              <TouchableOpacity 
                style={[styles.emergencyButton, styles.ambulanceButton]}
                onPress={() => {
                  toast.message("Calling Emergency Ambulance...");
                  // Note: In a real app, you would use Linking.openURL('tel:102')
                }}
              >
                <MaterialIcons name="emergency" size={24} color="white" />
                <View>
                  <Text style={styles.emergencyButtonText}>Ambulance</Text>
                  <Text style={styles.emergencyNumber}>102</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.emergencyButton, styles.hospitalButton]}
                onPress={() => {
                  toast.message("Showing nearby hospitals...");
                }}
              >
                <MaterialIcons name="local-hospital" size={24} color="white" />
                <View>
                  <Text style={styles.emergencyButtonText}>Find Nearby</Text>
                  <Text style={styles.emergencyNumber}>Hospitals</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  scrollView: {
    flex: 1,
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 12,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginLeft: 10,
    color: '#0A2463',
  },
  disclaimer: {
    backgroundColor: '#FFF3E0',
    padding: 15,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  disclaimerText: {
    marginLeft: 10,
    flex: 1,
    color: '#F57C00',
    fontSize: 14,
    lineHeight: 20,
  },
  inputContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    color: '#0A2463',
  },
  input: {
    borderWidth: 1.5,
    borderColor: '#E0E0E0',
    borderRadius: 10,
    padding: 12,
    marginBottom: 16,
    fontSize: 16,
    backgroundColor: '#F8F9FA',
  },
  symptomsInput: {
    height: 100,
    textAlignVertical: 'top',
  },
  button: {
    backgroundColor: '#0A2463',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  diagnosisContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  diagnosisText: {
    fontSize: 16,
    lineHeight: 24,
    color: '#2C3E50',
  },
  emergencySection: {
    marginBottom: 20,
  },
  emergencyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0A2463',
    marginBottom: 12,
  },
  emergencyButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  emergencyButton: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  ambulanceButton: {
    backgroundColor: '#DC3545',
  },
  hospitalButton: {
    backgroundColor: '#198754',
  },
  emergencyButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  emergencyNumber: {
    color: 'white',
    fontSize: 14,
    opacity: 0.9,
    marginLeft: 8,
  }
});
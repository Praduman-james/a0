import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { MedicalConsultation } from '../types/medical';

interface Props {
  consultations: MedicalConsultation[];
  onConsultationPress: (consultation: MedicalConsultation) => void;
}

export default function MedicalHistory({ consultations, onConsultationPress }: Props) {
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <Animated.View entering={FadeInUp.duration(600)} style={styles.container}>
      <Text style={styles.title}>Medical History</Text>
      <ScrollView style={styles.historyList}>
        {consultations.map((consultation, index) => (
          <TouchableOpacity
            key={consultation.id}
            style={styles.consultationCard}
            onPress={() => onConsultationPress(consultation)}
          >
            <MaterialIcons name="history" size={24} color="#2196F3" />
            <View style={styles.consultationInfo}>
              <Text style={styles.dateText}>{formatDate(consultation.timestamp)}</Text>
              <Text style={styles.symptomsText} numberOfLines={1}>
                {consultation.symptoms}
              </Text>
            </View>
            <MaterialIcons name="chevron-right" size={24} color="#757575" />
          </TouchableOpacity>
        ))}
      </ScrollView>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#0A2463',
  },
  historyList: {
    maxHeight: 300,
  },
  consultationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#F8F9FA',
    marginBottom: 8,
  },
  consultationInfo: {
    flex: 1,
    marginLeft: 12,
  },
  dateText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  symptomsText: {
    fontSize: 16,
    color: '#333',
  },
});